Trabalho por Higor Henrique e Lidimar
Para compilar use ./tp1 (nome do arquivo com as frases)
A chave para ser inserida deve ser parecida com essa I1.